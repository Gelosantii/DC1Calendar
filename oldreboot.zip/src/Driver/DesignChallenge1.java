package Driver;

import designchallenge1.CalendarProgram;

public class DesignChallenge1
{
    public static void main(String[] args)
    {
        CalendarProgram cp;
        cp = new CalendarProgram();
    }
}
