# DC1Calendar
Design Challenge for SWDESPA

Michael Angelo Barcena Santillan
Mirah Kelle Gadapan Rapanut

UML: https://www.lucidchart.com/invitations/accept/08e199b2-54f5-4b42-9726-f5bd35733808

Pattern Used: Template - Adapter - Observer
